print('🧠 Natural Core IA v4.7 carregado com sucesso!') 
