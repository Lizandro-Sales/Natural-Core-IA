print("🧠 IA de diagnóstico ativa e sincronizada.") 
