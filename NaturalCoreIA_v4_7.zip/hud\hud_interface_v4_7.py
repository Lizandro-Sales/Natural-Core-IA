print('💡 HUD Visual IA v4.7 inicializado...') 
