print("📊 HUD Visual IA v4.6 iniciado...") 
